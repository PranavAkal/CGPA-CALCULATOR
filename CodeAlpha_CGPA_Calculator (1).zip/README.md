# CodeAlpha_CGPA_Calculator

> Solution for **CodeAlpha C++ Programming Internship - Task 1: CGPA Calculator**

## Description
Compute semester GPA & overall CGPA with grade point weights and individual course breakdowns.

## Technologies & Concepts
- Vector data structures
- Weighted averages
- Stream formatting (iomanip)
- Input validation

## Compilation and Execution

### Using Make
```bash
make
make run
```

### Using g++ directly
```bash
g++ -std=c++17 -O2 main.cpp -o cgpa_calc && ./cgpa_calc
```

---
**Author**: Pranav Akal  
**Internship**: CodeAlpha C++ Programming  
