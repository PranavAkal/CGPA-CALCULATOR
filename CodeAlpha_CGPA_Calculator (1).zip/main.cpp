/**
 * ============================================================================
 * CodeAlpha Internship - C++ Programming
 * Task 1: CGPA Calculator
 * ============================================================================
 * Description:
 *   An interactive C++ application to compute semester Grade Point Average
 *   (GPA) and overall Cumulative Grade Point Average (CGPA) for university
 *   students. Calculates total credit hours, weighted grade points, and
 *   presents a formatted academic performance report.
 *
 * Compilation:
 *   g++ -std=c++17 -Wall -Wextra Task1_CGPA_Calculator.cpp -o cgpa_calc
 *   ./cgpa_calc
 * ============================================================================
 */

#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include <cctype>
#include <algorithm>
#include <limits>

struct Course {
    std::string code;
    std::string name;
    double credits;
    std::string letterGrade;
    double gradePoints; // Scale of 4.0 or 10.0
};

struct Semester {
    int semesterNumber;
    std::vector<Course> courses;
    double totalCredits;
    double totalPoints;
    double gpa;
};

// Convert standard letter grade into numerical grade points (4.0 scale)
double convertGradeToPoints(const std::string& rawGrade) {
    std::string grade = rawGrade;
    std::transform(grade.begin(), grade.end(), grade.begin(), ::toupper);

    if (grade == "A+" || grade == "A") return 4.00;
    if (grade == "A-") return 3.70;
    if (grade == "B+") return 3.30;
    if (grade == "B")  return 3.00;
    if (grade == "B-") return 2.70;
    if (grade == "C+") return 2.30;
    if (grade == "C")  return 2.00;
    if (grade == "C-") return 1.70;
    if (grade == "D+") return 1.30;
    if (grade == "D")  return 1.00;
    if (grade == "F")  return 0.00;

    // Try parsing as numeric point if user entered numbers directly
    try {
        double val = std::stod(rawGrade);
        if (val >= 0.0 && val <= 10.0) return val;
    } catch (...) {}

    return -1.0; // Invalid flag
}

void printDivider(char ch = '=', int len = 70) {
    std::cout << std::string(len, ch) << "\n";
}

int main() {
    std::cout << "\n";
    printDivider();
    std::cout << "         CODEALPHA INTERNSHIP - TASK 1: CGPA CALCULATOR\n";
    std::cout << "             Comprehensive Academic Performance Evaluator\n";
    printDivider();

    std::string studentName, studentId;
    std::cout << "\nEnter Student Full Name: ";
    std::getline(std::cin, studentName);
    std::cout << "Enter Student Registration ID: ";
    std::getline(std::cin, studentId);

    int numSemesters = 0;
    while (true) {
        std::cout << "\nEnter number of semesters to calculate (1-10): ";
        if (std::cin >> numSemesters && numSemesters >= 1 && numSemesters <= 10) {
            break;
        }
        std::cout << "[Error] Please enter a valid integer between 1 and 10.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    std::vector<Semester> academicRecord;
    double cumulativeTotalCredits = 0.0;
    double cumulativeTotalPoints = 0.0;

    for (int sem = 1; sem <= numSemesters; ++sem) {
        std::cout << "\n";
        printDivider('-', 60);
        std::cout << ">>> SEMESTER " << sem << " DETAILS\n";
        printDivider('-', 60);

        int numCourses = 0;
        while (true) {
            std::cout << "Enter number of courses in Semester " << sem << ": ";
            if (std::cin >> numCourses && numCourses > 0 && numCourses <= 15) {
                break;
            }
            std::cout << "[Error] Enter valid number of courses (1 - 15).\n";
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }

        Semester currentSemester;
        currentSemester.semesterNumber = sem;
        currentSemester.totalCredits = 0.0;
        currentSemester.totalPoints = 0.0;

        for (int c = 1; c <= numCourses; ++c) {
            Course course;
            std::cout << "\n  Course #" << c << ":\n";
            std::cout << "    Course Code (e.g. CS101): ";
            std::cin >> course.code;
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

            std::cout << "    Course Title: ";
            std::getline(std::cin, course.name);

            while (true) {
                std::cout << "    Credit Hours (e.g. 3.0 or 4.0): ";
                if (std::cin >> course.credits && course.credits > 0.0 && course.credits <= 10.0) {
                    break;
                }
                std::cout << "    [Error] Invalid credit hours. Please try again.\n";
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }

            while (true) {
                std::cout << "    Grade Obtained (A+, A, A-, B+, B, C+, C, D, F): ";
                std::cin >> course.letterGrade;
                double points = convertGradeToPoints(course.letterGrade);
                if (points >= 0.0) {
                    course.gradePoints = points;
                    break;
                }
                std::cout << "    [Error] Invalid grade. Accepted: A+, A, A-, B+, B, C+, C, D, F\n";
            }

            double weightedPoints = course.credits * course.gradePoints;
            currentSemester.totalCredits += course.credits;
            currentSemester.totalPoints += weightedPoints;
            currentSemester.courses.push_back(course);
        }

        currentSemester.gpa = (currentSemester.totalCredits > 0)
            ? (currentSemester.totalPoints / currentSemester.totalCredits)
            : 0.0;

        cumulativeTotalCredits += currentSemester.totalCredits;
        cumulativeTotalPoints += currentSemester.totalPoints;
        academicRecord.push_back(currentSemester);
    }

    double finalCGPA = (cumulativeTotalCredits > 0)
        ? (cumulativeTotalPoints / cumulativeTotalCredits)
        : 0.0;

    // Display formatted grade report
    std::cout << "\n\n";
    printDivider('=', 75);
    std::cout << "                      ACADEMIC TRANSCRIPT REPORT\n";
    std::cout << " Student Name : " << studentName << "\n";
    std::cout << " Student ID   : " << studentId << "\n";
    printDivider('=', 75);

    std::cout << std::fixed << std::setprecision(2);

    for (const auto& sem : academicRecord) {
        std::cout << "\n[ Semester " << sem.semesterNumber << " Summary ]\n";
        std::cout << std::left 
                  << std::setw(12) << "Code"
                  << std::setw(28) << "Course Name"
                  << std::setw(10) << "Credits"
                  << std::setw(10) << "Grade"
                  << std::setw(12) << "Points"
                  << "\n";
        printDivider('-', 72);

        for (const auto& c : sem.courses) {
            std::cout << std::left 
                      << std::setw(12) << c.code
                      << std::setw(28) << (c.name.length() > 26 ? c.name.substr(0, 24) + ".." : c.name)
                      << std::setw(10) << c.credits
                      << std::setw(10) << c.letterGrade
                      << std::setw(12) << (c.credits * c.gradePoints)
                      << "\n";
        }
        printDivider('-', 72);
        std::cout << "Semester Credits: " << sem.totalCredits 
                  << " | Quality Points: " << sem.totalPoints
                  << " | Semester GPA: " << sem.gpa << "\n";
    }

    printDivider('=', 75);
    std::cout << "\nFINAL CUMULATIVE SUMMARY:\n";
    std::cout << "  Total Semesters Evaluated : " << numSemesters << "\n";
    std::cout << "  Total Credit Hours Earned : " << cumulativeTotalCredits << "\n";
    std::cout << "  Total Quality Grade Points: " << cumulativeTotalPoints << "\n";
    std::cout << "  Overall CGPA              : " << finalCGPA << " / 4.00\n";

    // Performance appraisal feedback
    std::cout << "  Academic Standing         : ";
    if (finalCGPA >= 3.80) {
        std::cout << "First Class with Distinction (Summa Cum Laude)\n";
    } else if (finalCGPA >= 3.50) {
        std::cout << "Dean's Honor Roll (Magna Cum Laude)\n";
    } else if (finalCGPA >= 3.00) {
        std::cout << "First Division / Very Good Standing\n";
    } else if (finalCGPA >= 2.00) {
        std::cout << "Satisfactory / Good Standing\n";
    } else {
        std::cout << "Academic Warning / Needs Improvement\n";
    }
    printDivider('=', 75);
    std::cout << "Report generated successfully.\n\n";

    return 0;
}
